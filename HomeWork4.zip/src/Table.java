public interface Table {

    public final int[] columnWidths = {6, 10, 8, 5};

    public abstract void printStudents();


}
