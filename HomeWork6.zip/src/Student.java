public class Student {

    public String  name;

    public Student(){

    }
    public Student(String name){
        this.name = name;
    }

    public String getName(){
        return  this.name;
    }

}
