public class Book {

    public Book(String Author, Double Price, String Name){

        this.Author = Author;
        this.Price = Price;
        this.Name = Name;
        this.isBorrowed = false;
    }

    public String Author;

    public Double Price;

    public String Name;

    public boolean isBorrowed;



}
